//
//  PSDKAppsFlyerImpl.h
//  PSDKAppsFlyer
//
//  Created by Ariel Vardy on 8/12/14.
//  Copyright (c) 2014 TabTale. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <PublishingSDKCore/PublishingSDKCore.h>
#import "AppsFlyerTracker.h"

@interface PSDKAppsFlyerImpl : NSObject<PSDKAppsFlyer, PSDKConfigurationFetcherDelegate, PSDKAppLifeCycleDelegate, AppsFlyerTrackerDelegate>

- (id) initWithDevKey:(NSString*)devKey
             andAppId:(NSString*)appId
      appLifeCycleMgr:(PSDKAppLifeCycleMgr*)appLifeCycleMgr
             sendIDFA:(NSNumber*)sendIDFA
enablePurchaseTracking:(NSNumber*)enablePurchaseTracking;

@end

//
//  BannersImpl.h
//  Banners
//
//  Created by Gal Briner on 7/21/14.
//  Copyright (c) 2014 Tabtale. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <PublishingSDKCore/PublishingSDKCore.h>
#import "BannersInternalDelegate.h"
#import "BannersConfigurationDelegate.h"

@interface PSDKBannersImpl : NSObject<PSDKBanners, PSDKBannersConfigurationDelegate, PSDKBannersInternalDelegate, PSDKBanners>

- (id) initWithDelegate:(NSDictionary*)configuration
        appLifeCycleMgr:(PSDKAppLifeCycleMgr*)appLifeCycleMgr
     rootViewController:(id<PSDKRootViewController>)rootViewController
               delegate:(id<PSDKBannersDelegate>)delegate
            orientation:(NSString*)orientation
               language:(NSString*)language
                 splash:(id<PSDKSplash>)splash;

@property (nonatomic, retain) NSMutableArray* adsServices;

@end

//
//  PSDKAnalyticsImpl.h
//  PSDKAnalytics
//
//  Created by Ariel Vardy on 8/30/15.
//  Copyright (c) 2015 Tabtale. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <PublishingSDKCore/PublishingSDKCore.h>

@interface PSDKTimedEventData : NSObject

- (id) initWithTime:(NSDate*)date param:(NSDictionary*)dic targets:(AnalyticsType)targets;

@end

@interface PSDKAnalyticsImpl : NSObject<PSDKAnalyticsExt, PSDKConfigurationFetcherDelegate, PSDKLanguage, PSDKAppLifeCycleDelegate>

@property (nonatomic, strong) id<PSDKAnalyticsAgent> flurryAgent;
@property (nonatomic, strong) id<PSDKAnalyticsAgent> TTAgent;
@property (nonatomic, strong) id<PSDKAnalyticsAgent> deltaDna;

- (id) initWithDic:(NSDictionary*)config delegate:(id<PSDKAnalyticsDelegate>)delegate;
- (void) logEvent:(NSString*) eventName params:(NSDictionary*) params timed:(BOOL) timed;
- (void) endTimedEvent:(NSString*) eventName params:(NSDictionary*) params;

@end

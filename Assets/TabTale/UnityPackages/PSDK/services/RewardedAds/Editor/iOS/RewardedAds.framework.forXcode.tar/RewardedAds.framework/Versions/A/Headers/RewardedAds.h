//
//  RewardedAds.h
//  RewardedAds
//
//  Created by Liran Aknin on 6/11/14.
//  Copyright (c) 2014 Liran Aknin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <PublishingSDKCore/PublishingSDKCore.h>
#import <RewardedAds/RewardedAdsServiceImpl.h>

@interface RewardedAds : NSObject

@end
